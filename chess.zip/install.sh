sudo apt install nodejs
npm install
npm audit
npm audit fix
npm start